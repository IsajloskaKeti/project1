package com.example.bookaholic.persistence_or_repository;
import com.example.bookaholic.model.Category;

import java.util.List;
import java.util.Optional;
public interface CategoryRepository {
    List<Category> findAll();
    List<Category> findAllByName(String name);
    Optional<Category> findById(Long id);
    Category save(Category category);
    void deleteById(Long id);
}
