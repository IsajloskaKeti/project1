package com.example.bookaholic.persistence_or_repository;
import com.example.bookaholic.model.Book;
import java.util.List;
import java.util.Optional;
public interface BookRepository {
    List<Book> findAll();
    List<Book> findAllByCategoryId(Long categoryId);
    Optional<Book> findById(Long id);
    Book save(Book book);
    void deleteById(Long id);
}
