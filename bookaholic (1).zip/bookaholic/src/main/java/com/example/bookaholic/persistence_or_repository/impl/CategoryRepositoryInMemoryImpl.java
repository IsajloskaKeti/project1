package com.example.bookaholic.persistence_or_repository.impl;
import com.example.bookaholic.model.Category;
import com.example.bookaholic.persistence_or_repository.CategoryRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
@Repository
public class CategoryRepositoryInMemoryImpl implements CategoryRepository {
    private HashMap<Long, Category> categories;
    private AtomicLong counter;

    public CategoryRepositoryInMemoryImpl() {
        this.categories = new HashMap<>();
        this.counter = new AtomicLong(0);

          Category fantasy = new Category(1L, "Fantasy", "fantasy");
          Category adventure = new Category(2L, "Adventure", "adventure");
          Category romance = new Category(3L, "Romance", "romance");
          Category contemporary = new Category(4L, "Contemporary", "cotemporary");
          Category dystopian = new Category(5L, "Dystopian", "dystopian");
          Category mystery = new Category(6L, "Mystery", "mystery");
          Category horror = new Category(7L, "Horror", "horror");
          Category thriller = new Category(8L, "Thriller", "thriller");
          Category paranormal = new Category(9L, "Paranormal", "paranormal");
          Category historical_fiction = new Category(10L, "Historical fiction", "historical fiction");
          Category science_fiction = new Category(11L, "Science fiction", "science fiction");
          Category memoir = new Category(12L, "Memoir", "memoir");
          Category cooking = new Category(13L, "Cooking", "cooking");
          Category art = new Category(14L, "Art", "art");
          Category personal = new Category(15L, "Personal", "personal");
          Category biography = new Category(16L, "Biography", "Biography");


          this.categories.put(fantasy.getId(),fantasy);
          this.categories.put(adventure.getId(),adventure);
          this.categories.put(romance.getId(),romance);
          this.categories.put(contemporary.getId(),contemporary);
          this.categories.put(dystopian.getId(),dystopian);
          this.categories.put(mystery.getId(),mystery);
          this.categories.put(horror.getId(),horror);
          this.categories.put(thriller.getId(),thriller);
          this.categories.put(paranormal.getId(),paranormal);
          this.categories.put(historical_fiction.getId(),historical_fiction);
          this.categories.put(science_fiction.getId(),science_fiction);
          this.categories.put(memoir.getId(),memoir);
          this.categories.put(cooking.getId(),cooking);
          this.categories.put(art.getId(),art);
          this.categories.put(personal.getId(),personal);
          this.categories.put(biography.getId(),biography);

    }

    public Category getCategory(Long id)
    {
        return categories.get(id);
    }


    @Override
    public List<Category> findAll() {
        return new ArrayList<>(this.categories.values());
    }

    @Override
    public List<Category> findAllByName(String name) {
        return this.categories.values()
                .stream()
                .filter(item -> item.getName().contains(name))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Category> findById(Long id) {
        return Optional.ofNullable(this.categories.get(id));
    }

    @Override
    public Category save(Category category) {
        if (category.getId() == null) {
            category.setId(this.counter.getAndIncrement());
        }
        this.categories.put(category.getId(), category);
        return category;
    }

    @Override
    public void deleteById(Long id) {
        this.categories.remove(id);
    }
}
