package com.example.bookaholic.persistence_or_repository.impl;
import com.example.bookaholic.model.Book;
import com.example.bookaholic.model.Category;
import com.example.bookaholic.persistence_or_repository.BookRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;
@Repository
public class BookRepositoryImpl implements BookRepository{
    private HashMap<Long, Book> books;
    private Long counter;



    @PostConstruct
    public void init() {
        this.counter = 0L;
        this.books = new HashMap<>();
        Long id = this.generateKey();

        CategoryRepositoryInMemoryImpl c = new CategoryRepositoryInMemoryImpl();
        Category initC1=c.getCategory(1L);
        Category initC2=c.getCategory(10L);
        Category initC3=c.getCategory(16L);
        Category initC4=c.getCategory(1L);


        this.books.put(id, new Book(id,"The Lord of the Rings",3, initC1));
        id = this.generateKey();
        this.books.put(id, new Book(id,"The Victory Garden",4, initC2));
        id=this.generateKey();
        this.books.put(id, new Book(id,"The Diary of Anne Frank",5, initC3));
        id=this.generateKey();
        this.books.put(id, new Book(id,"The Hobbit",5, initC4));

    }


    @Override
    public List<Book> findAll() {
        return new ArrayList<>(this.books.values());
    }

    @Override
    public List<Book> findAllByCategoryId(Long categoryId) {
        return this.books.values()
                .stream()
                .filter(item -> item.getCategory().getId().equals(categoryId))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Book> findById(Long id) {
        return Optional.ofNullable(this.books.get(id));
    }

    @Override
    public Book save(Book book) {
        if (book.getId() == null) {
            book.setId(this.generateKey());
        }
        this.books.put(book.getId(), book);
        return book;
    }

    @Override
    public void deleteById(Long id) {
        this.books.remove(id);
    }

    private Long generateKey() {
        return ++counter;
    }

}
