package com.example.bookaholic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookaholicApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookaholicApplication.class, args);
    }

}
