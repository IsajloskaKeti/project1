package com.example.bookaholic.service_or_business;
import com.example.bookaholic.model.Category;

import java.util.List;
public interface CategoryService {
    List<Category> findAll();
    List<Category> findAllByName(String name);
    Category findById(Long id);
    Category save(Category manufacturer);
    Category update(Long id, Category manufacturer);
    Category updateName(Long id, String name);
    void deleteById(Long id);
}
