package com.example.bookaholic.model;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class Book {

    private Long id;
    @NotNull
    private String name;
    @NotNull (message="Quantity can't be empty field!")
    @Min(value = 0, message = "Quantity must be a positive number!")
    private Integer quantity;
    @NotNull
    private Category category;
    private String imageBase64;
    //    private MultipartFile image;

    //Constructors
    public Book(){}
    public Book(Long id, String name, Integer quantity, Category category)
    {
        this.id=id;
        this.name=name;
        this.quantity=quantity;
        this.category=category;
    }
    //Getters and setters
    public Long getId() {return id;}
    public void setId(Long id) {this.id=id;}
    public String getName() {return name;}
    public void setName(String name) {this.name=name;}
    public Integer getQuantity() {return quantity;}
    public void setQuantity(Integer quantity) {this.quantity=quantity;}
    public Category getCategory() {return category;}
    public void setCategory(Category category) {this.category=category;}
//    public MultipartFile getImage() {
//        return image;
//    }
//
//    public void setImage(MultipartFile image) {
//        this.image = image;
//    }

    public String getImageBase64() {
        return imageBase64;
    }
    public void setImageBase64(String imageBase64) {
        this.imageBase64 = imageBase64;
    }
}


